// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("system tests\n", stdout);
  return lionss_run_workload("system-tests");
}
