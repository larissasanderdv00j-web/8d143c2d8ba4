// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("duplication check\n", stdout);
  return lionss_run_workload("duplication-check");
}
